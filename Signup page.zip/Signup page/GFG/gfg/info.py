EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'vaibhavgupta.star002@gmail.com'
EMAIL_HOST_PASSWORD = 'ehtl tgmz adfi rqju'
EMAIL_PORT = 587